<?php
if (!defined('ABSPATH')) {
    die('No direct access.');
}
?>

<div class="emailoctopus-forms-list wrap">
    <div class="emailoctopus-form"></div>
</div>
