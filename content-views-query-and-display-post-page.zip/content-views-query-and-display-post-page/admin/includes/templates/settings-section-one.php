<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p style="margin-top:10px">Thank you for using Content Views (version <code><?php echo esc_html( PT_CV_Functions::plugin_info( PT_CV_FILE, 'Version' ) ); ?></code>).</p>